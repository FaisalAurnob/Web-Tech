<?php

	$db=mysqli_connect("localhost","root","","sms");  
			
			/* server name, username, password, your database name */

?>  